#pragma once


#ifndef RESTART_H
#define RESTART_H


#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

void cli_register_restart_command(void);


#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif  /* #ifndef VERSION_H_ */