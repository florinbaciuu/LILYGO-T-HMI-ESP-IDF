#pragma once

#ifndef UPTIME_H_
#define UPTIME_H_

#ifdef __cplusplus
extern "C" {
#endif

void cli_register_uptime_command(void);

#ifdef __cplusplus
}
#endif

#endif // UPTIME_H_
