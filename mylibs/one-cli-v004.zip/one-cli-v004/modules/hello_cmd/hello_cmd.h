#pragma once

#ifndef HELLO_H_
#define HELLO_H_

#ifdef __cplusplus
extern "C" {
#endif

void cli_register_hello_command(void);

#ifdef __cplusplus
}
#endif

#endif // UPTIME_H_
