#pragma once


#ifndef SET_CMD_H_
#define SET_CMD_H_


#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

void cli_register_set_command(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif  /* SET_CMD_H_ */