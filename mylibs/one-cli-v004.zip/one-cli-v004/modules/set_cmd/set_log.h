
#pragma once

int log_level(int argc, char **argv);