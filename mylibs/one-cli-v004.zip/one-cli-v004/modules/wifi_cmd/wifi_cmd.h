#pragma once


#ifndef WIFI_CMD_H_
#define WIFI_CMD_H_


#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

void cli_register_WiFi_join_command(void);


#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif  /* WIFI_CMD_H_ */