#pragma once

#ifndef PERFMON_H_
#define PERFMON_H_

#ifdef __cplusplus
extern "C" {
#endif

void cli_register_perfmon_command(void);

#ifdef __cplusplus
}
#endif

#endif // UPTIME_H_
