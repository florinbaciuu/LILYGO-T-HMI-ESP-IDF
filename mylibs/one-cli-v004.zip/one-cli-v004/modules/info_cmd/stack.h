#pragma once

#ifndef STACK_H
#define STACK_H

#ifdef __cplusplus
extern "C" {
#endif

void print_task_stack_info(void);

#ifdef __cplusplus
}
#endif

#endif // STACK_H
