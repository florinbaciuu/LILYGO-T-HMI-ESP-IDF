# OneCLI
## ESP32 S3
### Lilygo T HMI / Lilygo T Display S3 / Lilygo T QT Pro S3