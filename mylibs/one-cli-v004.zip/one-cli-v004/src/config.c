

#include "config.h"

static const char *TAG = "CLI";

char prompt[CONSOLE_PROMPT_MAX_LEN];