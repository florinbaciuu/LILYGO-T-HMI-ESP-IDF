# ChangeLog

## v0.2.0 - 2024-08-22

### Enhancements:

* feat(repo): support esp-ui phone 320x240 resolution
